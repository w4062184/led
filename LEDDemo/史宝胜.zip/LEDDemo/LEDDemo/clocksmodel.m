//
//  clocksmodel.m
//  LEDDemo
//
//  Created by shibaosheng on 15/10/29.
//  Copyright © 2015年 Sheng. All rights reserved.
//

#import "clocksmodel.h"

@implementation clocksmodel

@end
