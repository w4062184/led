//
//  clocksmodel.h
//  LEDDemo
//
//  Created by shibaosheng on 15/10/29.
//  Copyright © 2015年 Sheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface clocksmodel : NSObject

@property (nonatomic, strong) NSMutableArray *saveclocks;

@end
