//
//  AppDelegate.h
//  LEDDemo
//
//  Created by shibaosheng on 15/10/26.
//  Copyright © 2015年 Sheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

