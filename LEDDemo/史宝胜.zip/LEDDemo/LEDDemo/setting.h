//
//  setting.h
//  LEDDemo
//
//  Created by shibaosheng on 15/10/26.
//  Copyright © 2015年 Sheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface setting : UIView

@property (weak, nonatomic) IBOutlet UIButton *select;
@property (weak, nonatomic) IBOutlet UIButton *selectall;
@property (weak, nonatomic) IBOutlet UIView *views;
@property (weak, nonatomic) IBOutlet UIButton *cancal;

@end
